--
-- PostgreSQL database dump
--

\restrict 6FWYROl4VkTX6CPZLSoSeH1uBhXnM0VnnsAq8YfOzdFmzseJyXk3n3ieyhSjkgM

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg12+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO voxif;

--
-- Name: billing_accounts; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.billing_accounts (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL,
    plan character varying(50) NOT NULL,
    status character varying(9) NOT NULL,
    period_start timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.billing_accounts OWNER TO voxif;

--
-- Name: call_logs; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.call_logs (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    campaign_id uuid NOT NULL,
    sip_number character varying(20),
    duration_seconds integer NOT NULL,
    disposition character varying(14) NOT NULL,
    total_cost double precision NOT NULL,
    stt_tts_latency_ms integer NOT NULL,
    full_transcript json,
    recording_url character varying(1024)
);


ALTER TABLE public.call_logs OWNER TO voxif;

--
-- Name: campaign_leads; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.campaign_leads (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    campaign_id uuid NOT NULL,
    phone_number character varying(20) NOT NULL,
    name character varying(255),
    metadata_json json,
    status character varying(9) NOT NULL,
    call_attempts integer NOT NULL
);


ALTER TABLE public.campaign_leads OWNER TO voxif;

--
-- Name: campaigns; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.campaigns (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(9) NOT NULL,
    system_prompt text NOT NULL,
    stt_provider_id uuid,
    llm_provider_id uuid,
    tts_provider_id uuid,
    pipeline_config json,
    schedule_config json
);


ALTER TABLE public.campaigns OWNER TO voxif;

--
-- Name: knowledge_chunks; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.knowledge_chunks (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    document_id uuid NOT NULL,
    org_id uuid NOT NULL,
    chunk_index integer NOT NULL,
    content text NOT NULL,
    embedding public.vector(1536) NOT NULL
);


ALTER TABLE public.knowledge_chunks OWNER TO voxif;

--
-- Name: knowledge_documents; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.knowledge_documents (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    source character varying(512),
    status character varying(8) NOT NULL,
    chunk_count integer NOT NULL
);


ALTER TABLE public.knowledge_documents OWNER TO voxif;

--
-- Name: org_invites; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.org_invites (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL,
    email character varying(320) NOT NULL,
    role character varying(8) NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    accepted boolean NOT NULL,
    invited_by uuid
);


ALTER TABLE public.org_invites OWNER TO voxif;

--
-- Name: org_memberships; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.org_memberships (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    org_id uuid NOT NULL,
    role character varying(8) NOT NULL
);


ALTER TABLE public.org_memberships OWNER TO voxif;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.organizations (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    encrypted_dek bytea NOT NULL,
    dek_iv bytea NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.organizations OWNER TO voxif;

--
-- Name: provider_settings; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.provider_settings (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL,
    provider_type character varying(3) NOT NULL,
    provider_name character varying(50) NOT NULL,
    encrypted_config bytea NOT NULL,
    config_iv bytea NOT NULL,
    is_default boolean NOT NULL
);


ALTER TABLE public.provider_settings OWNER TO voxif;

--
-- Name: COLUMN provider_settings.provider_name; Type: COMMENT; Schema: public; Owner: voxif
--

COMMENT ON COLUMN public.provider_settings.provider_name IS 'e.g. deepgram, openai, cartesia, elevenlabs';


--
-- Name: security_events; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.security_events (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid,
    org_id uuid,
    event_type character varying(64) NOT NULL,
    ip character varying(64),
    detail json
);


ALTER TABLE public.security_events OWNER TO voxif;

--
-- Name: sip_trunk_settings; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.sip_trunk_settings (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    org_id uuid NOT NULL,
    label character varying(120) NOT NULL,
    mode character varying(8) NOT NULL,
    outbound_number character varying(32),
    encrypted_config bytea,
    config_iv bytea,
    livekit_trunk_id character varying(64),
    is_active boolean NOT NULL
);


ALTER TABLE public.sip_trunk_settings OWNER TO voxif;

--
-- Name: user_tokens; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.user_tokens (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    purpose character varying(14) NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used boolean NOT NULL,
    otp_hash character varying(64),
    attempts integer NOT NULL
);


ALTER TABLE public.user_tokens OWNER TO voxif;

--
-- Name: users; Type: TABLE; Schema: public; Owner: voxif
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    email character varying(320) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(255),
    is_active boolean NOT NULL,
    email_verified boolean NOT NULL,
    token_version integer NOT NULL,
    totp_secret character varying(64),
    totp_enabled boolean NOT NULL,
    backup_codes json,
    last_login_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO voxif;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.alembic_version (version_num) FROM stdin;
0007
\.


--
-- Data for Name: billing_accounts; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.billing_accounts (id, created_at, updated_at, org_id, plan, status, period_start) FROM stdin;
\.


--
-- Data for Name: call_logs; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.call_logs (id, created_at, updated_at, campaign_id, sip_number, duration_seconds, disposition, total_cost, stt_tts_latency_ms, full_transcript, recording_url) FROM stdin;
b3ce13cf-4e8d-4818-9d52-6378a78d4c4e	2026-06-19 19:23:21.837334+00	2026-06-19 19:23:21.837334+00	4881665e-b406-4b49-9a6f-1968e4c1efd7	\N	47	HUMAN_ANSWERED	0	0	{"turns": [{"role": "assistant", "text": "Hi! This is an AI assistant calling. How are you today?", "t": 6.59}, {"role": "user", "text": "Hello.", "t": 12.6}, {"role": "user", "text": "Hello. I'm fine. Hello. Hello.", "t": 22.4}, {"role": "user", "text": "Hello?", "t": 28.97}], "turn_count": 4}	\N
e7524958-2a09-4762-b63d-2304e606cfd6	2026-06-19 19:50:23.835894+00	2026-06-19 19:50:23.835894+00	4881665e-b406-4b49-9a6f-1968e4c1efd7	\N	50	HUMAN_ANSWERED	0	2018	{"turns": [{"role": "assistant", "text": "Hi! This is an AI assistant calling. How are you today?", "t": 6.26}, {"role": "user", "text": "I'm fine. How are you?", "t": 10.22}, {"role": "assistant", "text": "I'm glad to hear that! I'm doing well, thank you. How can I assist you today?", "t": 15.8}, {"role": "user", "text": "In Namin Pagal,", "t": 18.95}, {"role": "assistant", "text": "It seems like you might be referencing something specific, but I'm not familiar with \\"Namin Pagal.\\" Could you provide a bit more context or clarify what you need help with?", "t": 27.94}], "turn_count": 5}	\N
\.


--
-- Data for Name: campaign_leads; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.campaign_leads (id, created_at, updated_at, campaign_id, phone_number, name, metadata_json, status, call_attempts) FROM stdin;
\.


--
-- Data for Name: campaigns; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.campaigns (id, created_at, updated_at, org_id, name, status, system_prompt, stt_provider_id, llm_provider_id, tts_provider_id, pipeline_config, schedule_config) FROM stdin;
7dd7d59a-39cb-4f4b-831b-e3720403d88a	2026-06-19 18:18:28.624128+00	2026-06-19 18:18:28.624128+00	a8cd698a-6eda-4236-a376-aeaf5714cd12	Default Campaign	DRAFT	You are a professional AI voice agent. Be helpful, concise, and friendly.	\N	\N	\N	null	null
4881665e-b406-4b49-9a6f-1968e4c1efd7	2026-06-19 17:58:18.632781+00	2026-06-19 19:49:01.820945+00	5d845756-b9ed-474a-ad94-728f19fa7d5b	Default Campaign	DRAFT	You are a professional AI voice agent. Be helpful, concise, and friendly.	02b633eb-0aff-401b-8c92-f184532823ce	f0f2d33f-4936-4d95-b866-629bd1e75ca6	cfc96318-c662-4293-9bfe-5e496988bd8c	null	null
\.


--
-- Data for Name: knowledge_chunks; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.knowledge_chunks (id, created_at, updated_at, document_id, org_id, chunk_index, content, embedding) FROM stdin;
\.


--
-- Data for Name: knowledge_documents; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.knowledge_documents (id, created_at, updated_at, org_id, name, source, status, chunk_count) FROM stdin;
\.


--
-- Data for Name: org_invites; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.org_invites (id, created_at, updated_at, org_id, email, role, token_hash, expires_at, accepted, invited_by) FROM stdin;
\.


--
-- Data for Name: org_memberships; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.org_memberships (id, created_at, updated_at, user_id, org_id, role) FROM stdin;
6493aafb-dd6a-4786-b747-4543348ccd75	2026-06-19 17:56:55.909485+00	2026-06-19 17:56:55.909485+00	644fee40-12f6-4ae3-b0ac-c4a9d0ffcce5	5d845756-b9ed-474a-ad94-728f19fa7d5b	OWNER
444edb97-a66d-4436-8b72-f218e3b743dc	2026-06-19 18:17:52.50462+00	2026-06-19 18:17:52.50462+00	06372d2f-83c3-44ce-887b-c2abc0f09c5f	a8cd698a-6eda-4236-a376-aeaf5714cd12	OWNER
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.organizations (id, created_at, updated_at, name, slug, encrypted_dek, dek_iv, is_active) FROM stdin;
5d845756-b9ed-474a-ad94-728f19fa7d5b	2026-06-19 17:56:55.909485+00	2026-06-19 17:56:55.909485+00	voxif	voxif	\\x8e1121dccd4705a74632cd49048a37bc55ac0a85ef0085f50365a66d3ea7f1987fa1e7a8cf419f1b674ca09ad6012366	\\x70334b75677b0ba833e48c87	t
a8cd698a-6eda-4236-a376-aeaf5714cd12	2026-06-19 18:17:52.50462+00	2026-06-19 18:17:52.50462+00	Fast	fast	\\xe59f8dbb97bc9e93248ab0c64fe591d27bd95c3a49978625b94d665e2271dde5b171d836528586acdcb64d65d42dd7e0	\\x5a6455ea5394d53c9389bf9a	t
\.


--
-- Data for Name: provider_settings; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.provider_settings (id, created_at, updated_at, org_id, provider_type, provider_name, encrypted_config, config_iv, is_default) FROM stdin;
02b633eb-0aff-401b-8c92-f184532823ce	2026-06-19 18:01:24.54603+00	2026-06-19 18:01:24.54603+00	5d845756-b9ed-474a-ad94-728f19fa7d5b	STT	deepgram	\\xb01f327fdaf74ef7586c4b0ce937764c4797201a0f10dac602100002838e9675c11d15124d4c6e7a246acd22c8c4c73944565d0f03650eac68c3848515aacb4ecae2ee9174	\\xe4073892799ddfa66866cbdb	t
43f51662-bb93-4a4a-afaa-de211cacebc1	2026-06-19 18:01:24.771768+00	2026-06-19 18:01:24.771768+00	5d845756-b9ed-474a-ad94-728f19fa7d5b	LLM	openai	\\xcefec139efa34739e7cebe791fc4f3190c6742fcaf9d6430a63e5be9d64cfff8ca6f2d83b8b5e77efdf1c227cc268e444876395f26eca42be8c922d1c84a184136deb650e0dfcde61a086d43a16b3507ff08d48f537e97f0cdcf9b7d7a66b4e89ab2545df68453191e49a08c0a16287cfad8232de91d1e4134d1c7998893d3d5ffc770b592cde52bf92d2b49c18c49e65c9b6b0a6f08a12fdae4976b2bba8c728402bfd1f635c98b1c87ee0ad6bd82871de06a14cbb2821570f4f35973a527203b87aacb84402c73347a45818bf08195bec4826997c9c9	\\x2f1393186bd6ce1261a2f63d	t
cfc96318-c662-4293-9bfe-5e496988bd8c	2026-06-19 18:01:24.987886+00	2026-06-19 18:01:24.987886+00	5d845756-b9ed-474a-ad94-728f19fa7d5b	TTS	cartesia	\\xc0738dbb1713e7f0c1976305b1076bd61a797d8f82ce48ba6adf4b64298103cf2acab90f5eeb2ecbb6babfcaa7429267c9ff23e493f33f59cf1f	\\xfc983b2d89028e9c2a80540d	t
f0f2d33f-4936-4d95-b866-629bd1e75ca6	2026-06-19 19:49:01.820945+00	2026-06-19 19:49:01.820945+00	5d845756-b9ed-474a-ad94-728f19fa7d5b	LLM	openai	\\xcc08d967ad28ca7f551b272657fb7dd4980e8d6b0ab143eb697f0e69be893ab5cc4e9c276421e1432489a26bc333e14808fec5e82bececc818837ba735c7eba6ae067caafc7e15160d272f8f06867874e61afc33b6801d75f063b719b30254cd2c555a5eba348ddd2c11d703a7677c2824624240801f2c80ba1abf33b1bb2e562dbb8c5a3b10f3a2be3273864ccfe01e5799b5ba4f7599ba22d6ed324e2c2df28f2c6d01d9ede3754225b887f10f0728c0d973965a47988a71f598a563281d6eade567333d1183e97a406a08a4e5afb237da657a58da80	\\x272847766561eb08405298de	t
\.


--
-- Data for Name: security_events; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.security_events (id, created_at, updated_at, user_id, org_id, event_type, ip, detail) FROM stdin;
f64fb194-d6f6-4c0a-8ce5-23848ea38e84	2026-06-19 15:27:22.519419+00	2026-06-19 15:27:22.519419+00	a0a55f20-9c96-49a8-915e-91c75b7a5c21	c5e3b382-b646-493e-8015-e9f7e2ac5f97	user.registered	172.18.0.8	null
63bb60be-e980-4faf-bfc6-a8e875655460	2026-06-19 17:38:03.945434+00	2026-06-19 17:38:03.945434+00	d7f81268-84c6-4931-93fe-65d8c5c60c52	388206f5-c96e-4a4e-a5d2-cacbd7c5fd03	user.registered	172.18.0.8	null
0a2e736e-9376-491d-a972-03f676d44928	2026-06-19 17:40:32.850732+00	2026-06-19 17:40:32.850732+00	d7f81268-84c6-4931-93fe-65d8c5c60c52	\N	email.verification_resent	172.18.0.8	null
2698974b-f273-41e2-96da-6b2ececc77e1	2026-06-19 17:50:08.438535+00	2026-06-19 17:50:08.438535+00	d9c6e7ae-059a-473f-8bc8-8a4a24a764d0	725ee845-596f-440d-a62e-2233db525d43	user.registered	172.18.0.8	null
44a85e8a-ac5e-4de1-8eb2-4a7f297904d6	2026-06-19 17:50:09.915866+00	2026-06-19 17:50:09.915866+00	d9c6e7ae-059a-473f-8bc8-8a4a24a764d0	\N	login.success	172.18.0.8	null
092f4933-6801-4e65-8b36-da46a0d1f832	2026-06-19 17:52:41.745455+00	2026-06-19 17:52:41.745455+00	e3dd5c71-f0d1-4615-86d3-bb038c0af846	e0006811-4b97-46a4-81e6-e5e7a990d672	user.registered	172.18.0.8	null
e21be16f-0552-48cc-8c6b-9ae9c09641e5	2026-06-19 17:53:05.78235+00	2026-06-19 17:53:05.78235+00	e3dd5c71-f0d1-4615-86d3-bb038c0af846	\N	email.verified_otp	172.18.0.8	null
2780f326-b145-438c-85d2-cce4acde9e91	2026-06-19 17:53:08.686788+00	2026-06-19 17:53:08.686788+00	703d66b0-1178-4ea6-98b8-6b1776964c77	67ce2984-a897-4e6b-997b-3c8bd46b422e	user.registered	172.18.0.8	null
844ca158-af35-42e8-a6cc-363597323512	2026-06-19 17:56:55.909485+00	2026-06-19 17:56:55.909485+00	644fee40-12f6-4ae3-b0ac-c4a9d0ffcce5	5d845756-b9ed-474a-ad94-728f19fa7d5b	user.registered	172.18.0.8	null
6118d36f-5c61-448f-986f-0d1e4ae1a4d3	2026-06-19 17:58:17.998517+00	2026-06-19 17:58:17.998517+00	644fee40-12f6-4ae3-b0ac-c4a9d0ffcce5	\N	email.verified_otp	172.18.0.8	null
016b27d7-6bb3-4659-a87a-8214a3443925	2026-06-19 18:17:52.50462+00	2026-06-19 18:17:52.50462+00	06372d2f-83c3-44ce-887b-c2abc0f09c5f	a8cd698a-6eda-4236-a376-aeaf5714cd12	user.registered	172.18.0.8	null
5451f310-b7e9-48f7-86af-5e182f708e52	2026-06-19 18:18:23.856692+00	2026-06-19 18:18:23.856692+00	06372d2f-83c3-44ce-887b-c2abc0f09c5f	\N	email.verified_otp	172.18.0.8	null
\.


--
-- Data for Name: sip_trunk_settings; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.sip_trunk_settings (id, created_at, updated_at, org_id, label, mode, outbound_number, encrypted_config, config_iv, livekit_trunk_id, is_active) FROM stdin;
\.


--
-- Data for Name: user_tokens; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.user_tokens (id, created_at, updated_at, user_id, purpose, token_hash, expires_at, used, otp_hash, attempts) FROM stdin;
7142526b-d8c5-4237-b6bd-4bb82bb57bf6	2026-06-19 17:56:55.909485+00	2026-06-19 17:58:17.998517+00	644fee40-12f6-4ae3-b0ac-c4a9d0ffcce5	EMAIL_VERIFY	c788bef31e99485ba200c4617db73c44b51539e861919ad996bcfc0821027e3c	2026-06-21 17:56:56.000405+00	t	1cccd72d5d0d4e39918e24a0a84436d4df3e23c270612c2e4dec3ee82f6c126f	0
a95b0ade-f56c-4a98-8d03-27bf9f4121ce	2026-06-19 18:17:52.50462+00	2026-06-19 18:18:23.856692+00	06372d2f-83c3-44ce-887b-c2abc0f09c5f	EMAIL_VERIFY	4e7b293480ab1ff60225c42dfd5f585da491263365c0cc09ca8964b243662e49	2026-06-21 18:17:52.604095+00	t	861846a21105cf439ab95455aa01a9dfb4e258acd92203384ecbf9ce460ac233	0
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: voxif
--

COPY public.users (id, created_at, updated_at, email, hashed_password, full_name, is_active, email_verified, token_version, totp_secret, totp_enabled, backup_codes, last_login_at) FROM stdin;
644fee40-12f6-4ae3-b0ac-c4a9d0ffcce5	2026-06-19 17:56:55.909485+00	2026-06-19 17:58:17.998517+00	m.tashkeelpasha1@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$XhGFmYJE/dogmfui1nzcEQ$bdfellIFqCGJUU4Ez/oJV941PjEmgb6TBI6LiLi+mVw	\N	t	t	0	\N	f	\N	\N
06372d2f-83c3-44ce-887b-c2abc0f09c5f	2026-06-19 18:17:52.50462+00	2026-06-19 18:18:23.856692+00	k230043@nu.edu.pk	$argon2id$v=19$m=65536,t=3,p=4$O74ZloDPPD4+qeO57MLQXQ$D2BSyqie+RZrzczx4DALB1LDH90PCWXPXV2iST1ArvY	\N	t	t	0	\N	f	\N	\N
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: billing_accounts billing_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.billing_accounts
    ADD CONSTRAINT billing_accounts_pkey PRIMARY KEY (id);


--
-- Name: call_logs call_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.call_logs
    ADD CONSTRAINT call_logs_pkey PRIMARY KEY (id);


--
-- Name: campaign_leads campaign_leads_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.campaign_leads
    ADD CONSTRAINT campaign_leads_pkey PRIMARY KEY (id);


--
-- Name: campaigns campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_pkey PRIMARY KEY (id);


--
-- Name: knowledge_chunks knowledge_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.knowledge_chunks
    ADD CONSTRAINT knowledge_chunks_pkey PRIMARY KEY (id);


--
-- Name: knowledge_documents knowledge_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.knowledge_documents
    ADD CONSTRAINT knowledge_documents_pkey PRIMARY KEY (id);


--
-- Name: org_invites org_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.org_invites
    ADD CONSTRAINT org_invites_pkey PRIMARY KEY (id);


--
-- Name: org_memberships org_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.org_memberships
    ADD CONSTRAINT org_memberships_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: provider_settings provider_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.provider_settings
    ADD CONSTRAINT provider_settings_pkey PRIMARY KEY (id);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: sip_trunk_settings sip_trunk_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.sip_trunk_settings
    ADD CONSTRAINT sip_trunk_settings_pkey PRIMARY KEY (id);


--
-- Name: billing_accounts uq_billing_accounts_org; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.billing_accounts
    ADD CONSTRAINT uq_billing_accounts_org UNIQUE (org_id);


--
-- Name: org_memberships uq_org_membership_user_org; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.org_memberships
    ADD CONSTRAINT uq_org_membership_user_org UNIQUE (user_id, org_id);


--
-- Name: sip_trunk_settings uq_sip_trunk_org; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.sip_trunk_settings
    ADD CONSTRAINT uq_sip_trunk_org UNIQUE (org_id);


--
-- Name: user_tokens user_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.user_tokens
    ADD CONSTRAINT user_tokens_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_billing_accounts_org_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE UNIQUE INDEX ix_billing_accounts_org_id ON public.billing_accounts USING btree (org_id);


--
-- Name: ix_call_logs_campaign_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_call_logs_campaign_id ON public.call_logs USING btree (campaign_id);


--
-- Name: ix_campaign_leads_campaign_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_campaign_leads_campaign_id ON public.campaign_leads USING btree (campaign_id);


--
-- Name: ix_campaigns_org_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_campaigns_org_id ON public.campaigns USING btree (org_id);


--
-- Name: ix_knowledge_chunks_document_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_knowledge_chunks_document_id ON public.knowledge_chunks USING btree (document_id);


--
-- Name: ix_knowledge_chunks_embedding_hnsw; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_knowledge_chunks_embedding_hnsw ON public.knowledge_chunks USING hnsw (embedding public.vector_cosine_ops);


--
-- Name: ix_knowledge_chunks_org_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_knowledge_chunks_org_id ON public.knowledge_chunks USING btree (org_id);


--
-- Name: ix_knowledge_documents_org_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_knowledge_documents_org_id ON public.knowledge_documents USING btree (org_id);


--
-- Name: ix_org_invites_email; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_org_invites_email ON public.org_invites USING btree (email);


--
-- Name: ix_org_invites_org_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_org_invites_org_id ON public.org_invites USING btree (org_id);


--
-- Name: ix_org_invites_token_hash; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_org_invites_token_hash ON public.org_invites USING btree (token_hash);


--
-- Name: ix_org_memberships_org_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_org_memberships_org_id ON public.org_memberships USING btree (org_id);


--
-- Name: ix_org_memberships_user_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_org_memberships_user_id ON public.org_memberships USING btree (user_id);


--
-- Name: ix_organizations_slug; Type: INDEX; Schema: public; Owner: voxif
--

CREATE UNIQUE INDEX ix_organizations_slug ON public.organizations USING btree (slug);


--
-- Name: ix_provider_settings_org_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_provider_settings_org_id ON public.provider_settings USING btree (org_id);


--
-- Name: ix_security_events_event_type; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_security_events_event_type ON public.security_events USING btree (event_type);


--
-- Name: ix_security_events_org_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_security_events_org_id ON public.security_events USING btree (org_id);


--
-- Name: ix_security_events_user_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_security_events_user_id ON public.security_events USING btree (user_id);


--
-- Name: ix_sip_trunk_settings_org_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_sip_trunk_settings_org_id ON public.sip_trunk_settings USING btree (org_id);


--
-- Name: ix_user_tokens_token_hash; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_user_tokens_token_hash ON public.user_tokens USING btree (token_hash);


--
-- Name: ix_user_tokens_user_id; Type: INDEX; Schema: public; Owner: voxif
--

CREATE INDEX ix_user_tokens_user_id ON public.user_tokens USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: voxif
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: billing_accounts billing_accounts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.billing_accounts
    ADD CONSTRAINT billing_accounts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: call_logs call_logs_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.call_logs
    ADD CONSTRAINT call_logs_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON DELETE CASCADE;


--
-- Name: campaign_leads campaign_leads_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.campaign_leads
    ADD CONSTRAINT campaign_leads_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON DELETE CASCADE;


--
-- Name: campaigns campaigns_llm_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_llm_provider_id_fkey FOREIGN KEY (llm_provider_id) REFERENCES public.provider_settings(id) ON DELETE SET NULL;


--
-- Name: campaigns campaigns_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: campaigns campaigns_stt_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_stt_provider_id_fkey FOREIGN KEY (stt_provider_id) REFERENCES public.provider_settings(id) ON DELETE SET NULL;


--
-- Name: campaigns campaigns_tts_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_tts_provider_id_fkey FOREIGN KEY (tts_provider_id) REFERENCES public.provider_settings(id) ON DELETE SET NULL;


--
-- Name: knowledge_chunks knowledge_chunks_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.knowledge_chunks
    ADD CONSTRAINT knowledge_chunks_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.knowledge_documents(id) ON DELETE CASCADE;


--
-- Name: knowledge_chunks knowledge_chunks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.knowledge_chunks
    ADD CONSTRAINT knowledge_chunks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: knowledge_documents knowledge_documents_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.knowledge_documents
    ADD CONSTRAINT knowledge_documents_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_invites org_invites_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.org_invites
    ADD CONSTRAINT org_invites_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_memberships org_memberships_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.org_memberships
    ADD CONSTRAINT org_memberships_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_memberships org_memberships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.org_memberships
    ADD CONSTRAINT org_memberships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: provider_settings provider_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.provider_settings
    ADD CONSTRAINT provider_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: sip_trunk_settings sip_trunk_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.sip_trunk_settings
    ADD CONSTRAINT sip_trunk_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: user_tokens user_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voxif
--

ALTER TABLE ONLY public.user_tokens
    ADD CONSTRAINT user_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 6FWYROl4VkTX6CPZLSoSeH1uBhXnM0VnnsAq8YfOzdFmzseJyXk3n3ieyhSjkgM

